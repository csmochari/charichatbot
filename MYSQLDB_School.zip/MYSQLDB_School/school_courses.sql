-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: school
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `c_id` varchar(100) NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `c_description` varchar(100) NOT NULL,
  `professor` varchar(100) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES ('CS100','Intro to Programming','Introduction of programming concepts using Python.','Lincoln Brown'),('CS110','Hardware Fundamentals','Introductory course of fundamental hardware parts of a computer','Lincoln Brown'),('CS145','Introduction to Networking','Discusses the basic concepts of computer networking','Nina Belle'),('CS201','Web Development','An introductory web development course w','Timothy Vang'),('CS210','Discrete Math','Discusses the fundamental topics of discrete math','Sonia Hernandez'),('CS220','C Programming','Students will develop programs using the C programming language','Nina Belle'),('CS235','Java Programming','Students will develop programs using the Java Programming language','Peter Nichols'),('CS300','Data Structures','Introduction to fundamental data structures ','Peter Nichols'),('CS310','Computer Security','Discusses various computer security topics ','Timothy Vang'),('CS330','Software Engineering','Students will apply their programming skills','Scott Lu'),('CS335','Artificial Intelligence','Students will study various algorithms ','Bob Carson'),('CS345','Robotics','Students will learn the concepts of robotics ','Nina Belle'),('CS400','Advanced Networking','Discussion of advanced topics in networking','Scott Lu'),('CS420','Advanced Computer Security','Discussion of advanced topics in computer security','Peter Nichols'),('CS430','Advanced Software Engineering','Discussion of advanced topics in software engineering','Bob Carson'),('CS445','Senior Project','Students create their own personal programming project','Peter Nichols');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-13  1:22:42
