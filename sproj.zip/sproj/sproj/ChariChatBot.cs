﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace sproj
{
    public partial class ChariChatBot : Form
    {
        ArrayList futurecourses = new ArrayList();
        ArrayList courses = new ArrayList();
        ArrayList course_prereqs = new ArrayList();
        ArrayList times = new ArrayList();

        public ChariChatBot()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

            //Default message displayed when chatbot application is open.
            screen.Items.Add("CHARI: Hello and welcome to computer science major advising! To get started please enter your Student ID");

        }

        //This query returns the student's first name associated with the student ID
        private void query1()
        {
            //connection to the MySQL database 
            String connectionString = "server=127.0.0.1;user id=root; password=123; persistsecurityinfo=True;database=school; ";
            MySqlConnection connection = new MySqlConnection(connectionString);
            //grpQuestion.Visible = true;
            try
            {
                //The query to be used
                connection.Open();
                MySqlCommand command = new MySqlCommand("SELECT f_name FROM students WHERE s_id= " + txtBox.Text, connection);
               

                //Print the first name of the student that is associated with the student ID
                if (command.ExecuteScalar() != null)
                {
                    query5(txtBox.Text);
                    screen.Items.Add("Me: " + txtBox.Text);
                   
                    txtBox.Clear();

                    screen.Items.Add("CHARI: Hello " + command.ExecuteScalar().ToString() + ", what can I assist you with today?");
                   

                }
                else
                {
                    screen.Items.Add("Me: " + txtBox.Text);
                    txtBox.Clear();
                    screen.Items.Add("CHARI: I cannot find that student ID");
                 
                }
            }
            catch (MySqlException ex)
            {

            }
            finally
            {

                connection.Close();
                connection.Dispose();

            }

        }

        //Executes the first set of requests by the student
        private void set1()
        {
           
            while (txtBox.Text != "")
            {
                screen.Items.Add("Me: " + txtBox.Text);
                String s = screen.Items[1].ToString();
                int start = s.IndexOf('2');
                s = s.Substring(start).Trim();
                String[] output1 = new string[] { "CHARI: Ok, let me take a look at your records", "CHARI: Give me a moment while I retrieve your records", "CHARI: Retrieving your records..."};
                String[] output2 = new string[] { "CHARI: Sorry, I do not understand your request.", "CHARI: Sorry, please repeat your request." };
                Random random = new Random();
                int index= random.Next(0, output1.Length);
                int index2 = random.Next(0, output2.Length);
                String str = txtBox.Text;


                if (string.Equals(str, "courses", StringComparison.OrdinalIgnoreCase) || txtBox.Text.Contains("courses") || txtBox.Text.Contains("course") || string.Equals(str, "course information", StringComparison.OrdinalIgnoreCase))
                {
                    advMenu.Visible = true;
                    courseBox.Visible = true;
                    txtBox.Clear();
                   
                    


                }
                else if (string.Equals(str, "advising", StringComparison.OrdinalIgnoreCase) || txtBox.Text.Contains("advising") || txtBox.Text.Contains("major advising") || string.Equals(str, "major advising", StringComparison.OrdinalIgnoreCase))
                {
                    advMenu.Visible = true;
                    screen.Items.Add(output1[index]);
                    txtBox.Clear();
                    if (screen.Items[2].ToString() != "CHARI: I cannot find that student ID")
                    {
                        query2(s);
                    }
                    else
                    {
                        //if error getting student ID in the first try, execute with correct student ID
                        String s2 = screen.Items[3].ToString();
                        int start2 = s.IndexOf('2');
                        s2 = s2.Substring(start).Trim();
                        query2(s2);
                    }
                    txtBox.Clear();

                }
                else if (string.Equals(str, "register", StringComparison.OrdinalIgnoreCase) || txtBox.Text.Contains("register") || txtBox.Text.Contains("registration") || string.Equals(str, "registration", StringComparison.OrdinalIgnoreCase))
                {
                    advMenu.Visible = true;
                    grpRegister.Visible = true;
                    txtBox.Clear();

                }

                //input that can't be understood
                else
                {
                    advMenu.Visible = true;
                    screen.Items.Add(output2[index2]+" If you need assistance, Please select an option from the menu above.");
                    txtBox.Clear();
                }
                             
            }
        }

        //This query returns information from student_current_courses table 
        private void query2(String id)
        {
            //connection to the MySQL database 
            String connectionString = "server=127.0.0.1;user id=root; password=123; persistsecurityinfo=True;database=school; ";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                //The query to be used
                connection.Open();
                MySqlCommand command2 = new MySqlCommand("SELECT * FROM student_current_courses WHERE s_id= " + id, connection);

                MySqlDataReader dataReader = command2.ExecuteReader();

                //returns student data 
                while (dataReader.Read())
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Student Courses For " + dataReader.GetString(3) + ":");
                    screen.Items.Add("Student ID: " + dataReader.GetString(10));
                    screen.Items.Add("Name: " + dataReader.GetString(1) + " " + dataReader.GetString(2));
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Courses");

                    //return list of courses
                    for (int i = 4; i < 9; i++)
                    {
                        //"-" is a place holder for null values in the table. Do not want to return null values
                        if (dataReader.GetString(i) != "-")
                        {
                            screen.Items.Add((i - 3) + ":" + dataReader.GetString(i));
                            //courses.Add(dataReader.GetString(i));
                            course_prereqs.Add(dataReader.GetString(i));
                        }

                    }
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("");
                    if (course_prereqs.Contains("CS100"))
                    {
                        screen.Items.Add("CHARI: You may register for: CS 201, CS 210, CS 220, CS 235");
                    }
                    else if (course_prereqs.Contains("145"))
                    {
                        screen.Items.Add("CHARI: You may register for: CS 310");
                    }
                    else if (course_prereqs.Contains("CS235") && course_prereqs.Contains("CS210"))
                    {
                        screen.Items.Add("CHARI: You may register for: CS 300");
                    }
                    else if (course_prereqs.Contains("CS300"))
                    {
                        screen.Items.Add("CHARI: You may register for: CS 330, CS 335, CS 400");
                    }
                    else if (course_prereqs.Contains("CS335"))
                    {
                        screen.Items.Add("CHARI: You may register for: CS 345");
                    }
                    else if (course_prereqs.Contains("CS330"))
                    {
                        screen.Items.Add("CHARI: You may register for: CS 430");
                    }
                    else if (course_prereqs.Contains("CS310"))
                    {
                        screen.Items.Add("CHARI: You may register for: CS 420");
                    }
                    else if (course_prereqs.Contains("CS300")&&course_prereqs.Contains("CS330"))
                    {
                        screen.Items.Add("CHARI: You may register for: CS 445");
                    }


                }

            }
            catch (MySqlException ex)
            {

            }
            finally
            {

                connection.Close();
                connection.Dispose();

            }

        }


        private void query3(String courseID)
        {
            //connection to the MySQL database 
            String connectionString = "server=127.0.0.1;user id=root; password=123; persistsecurityinfo=True;database=school; ";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                //The query to be used
                connection.Open();
                MySqlCommand command3 = new MySqlCommand("SELECT * FROM courses WHERE c_id= " + courseID, connection);

                MySqlDataReader dataReader = command3.ExecuteReader();

                //returns student data 
                while (dataReader.Read())
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course " + dataReader.GetString(0) + ":");
                    screen.Items.Add("Course Name: " + dataReader.GetString(1));
                    screen.Items.Add("Description: " + dataReader.GetString(2));
                    screen.Items.Add("Professor: " + dataReader.GetString(3));
                    screen.Items.Add("------------------------------------------");


                }
            }
            catch (MySqlException ex)
            {

            }
            finally
            {

                connection.Close();
                connection.Dispose();

            }

        }
        //Executed when the Submit button is clicked
        private void btnSubmit_Click(object sender, EventArgs e)
        {

            query1();
            set1();




        }

        //Executed when the End button is clicked
        private void btnEnd_Click(object sender, EventArgs e)
        {
            //possible responses 
            String[] output = new string[] { "CHARI: See you next time!", "CHARI: Have a great day!", "CHARI: goodbye"};
            Random random = new Random();
            int index = random.Next(0, output.Length);

            screen.Items.Add(output[index]);
            //this.Close();
        }

        private void CS100_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 100: ");
                    screen.Items.Add("Course Name: Intro to Programming");
                    screen.Items.Add("Description: Introduction of programming concepts using Python.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Lincoln Brown");
                    screen.Items.Add("Prerequisites: none");
                    screen.Items.Add("Time: MW 3p-4:45");
                    screen.Items.Add("------------------------------------------");
                }
            }
        }

        private void CS110_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 110: ");
                    screen.Items.Add("Course Name: Hardware Fundamentals");
                    screen.Items.Add("Description: Introductory course of fundamental hardware parts of a computer.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Lincoln Brown");
                    screen.Items.Add("Prerequisites: none");
                    screen.Items.Add("Time: TTH 1p-2:45");
                    screen.Items.Add("------------------------------------------");
                }
            }

        }

        private void CS145_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 145");
                    screen.Items.Add("Course Name: Introduction to Networking");
                    screen.Items.Add("Description: Discusses the basic concepts of computer networking.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Nina Belle");
                    screen.Items.Add("Prerequisites: none");
                    screen.Items.Add("Time: MW 2p-3:45");
                    screen.Items.Add("------------------------------------------");
                }
            }

        }

        private void CS201_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 201: ");
                    screen.Items.Add("Course Name: Web Development");
                    screen.Items.Add("Description: An introductory web development course where students will implement HTML, CSS, and JavaScript to create a webpage.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Timothy Vang");
                    screen.Items.Add("Prerequisites: CS 100");
                    screen.Items.Add("Time: TTH 8a-9:45");
                    screen.Items.Add("------------------------------------------");

                }
            }

        }

        private void CS210_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 210: Discrete Math");
                    screen.Items.Add("Course Name: Discrete Math");
                    screen.Items.Add("Description: Discusses the fundamental topics of discrete math.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Sonia Hernandez");
                    screen.Items.Add("Prerequisites: CS 100");
                    screen.Items.Add("Time: MW 9a-10:45");
                    screen.Items.Add("------------------------------------------");
                }
            }

        }

        private void CS220_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 220: ");
                    screen.Items.Add("Course Name: C Programming");
                    screen.Items.Add("Description: Students will develop programs using the C programming language.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Nina Belle");
                    screen.Items.Add("Prerequisites: CS 100");
                    screen.Items.Add("Time: F 2p-5");
                    screen.Items.Add("------------------------------------------");
                }
            }

            }

            private void CS235_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 235: ");
                    screen.Items.Add("Course Name: Java Programming");
                    screen.Items.Add("Description: Students will develop programs using the Java Programming language.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Peter Nichols");
                    screen.Items.Add("Prerequisites: CS 100");
                    screen.Items.Add("Time: TTH 9a-10:45");
                    screen.Items.Add("------------------------------------------");

                }
            }

        }

        private void CS300_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 300: ");
                    screen.Items.Add("Course Name: Data Structures");
                    screen.Items.Add("Description: Introduction to fundamental data structures such as arrays, linked lists, etc.");
                    screen.Items.Add("and their application in programming assignments.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Peter Nichols");
                    screen.Items.Add("Prerequisites: CS 235 and CS 210");
                    screen.Items.Add("Time: MW 2p-3:45");
                    screen.Items.Add("------------------------------------------");
                }
            }

        }

        private void CS310_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 310: ");
                    screen.Items.Add("Course Name: Computer Security");
                    screen.Items.Add("Description: Discusses various computer security topics and how one can protect themselves from various security issues.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Timothy Vang");
                    screen.Items.Add("Prerequisites: CS 145");
                    screen.Items.Add("Time: MW 6p-7:45");
                    screen.Items.Add("------------------------------------------");
                }
            }

        }

        private void CS330_CheckedChanged(object sender, EventArgs e)

        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 330: ");
                    screen.Items.Add("Course Name: Software Engineering");
                    screen.Items.Add("Description: Students will apply their programming skills on various programming projects and learn the software development process.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Scott Lu");
                    screen.Items.Add("Prerequisites: CS 300");
                    screen.Items.Add("Time: MW 2p-3:45");
                    screen.Items.Add("------------------------------------------");
                }
            }

        }

        private void CS335_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 335: ");
                    screen.Items.Add("Course Name: Artificial Intelligence");
                    screen.Items.Add("Description: Students will study various algorithms used in developing artificial intelligence-based applications");
                    screen.Items.Add("as well as apply their knowledge in programming projects.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Bob Carson");
                    screen.Items.Add("Prerequisites: CS 300");
                    screen.Items.Add("Time: TTH 4p-5:45");
                    screen.Items.Add("------------------------------------------");
                }
            }

        }

        private void CS345_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 345: ");
                    screen.Items.Add("Course Name: Robotics");
                    screen.Items.Add("Description: Students will learn the concepts of robotics and how it implements artificial intelligence.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Nina Belle");
                    screen.Items.Add("Prerequisites: CS 335");
                    screen.Items.Add("Time: TTH 7p-8:45");
                    screen.Items.Add("------------------------------------------");
                }
            }

        }

        private void CS400_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 400: ");
                    screen.Items.Add("Course Name: Advanced Networking");
                    screen.Items.Add("Description: Discussion of advanced topics in networking.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Scott Lu");
                    screen.Items.Add("Prerequisites: CS 300");
                    screen.Items.Add("Time: TTH 5p-6:45");
                    screen.Items.Add("------------------------------------------");
                }
            }


        }

        private void CS420_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 420: ");
                    screen.Items.Add("Course Name: Advanced Computer Security");
                    screen.Items.Add("Description: Discussion of advanced topics in computer security.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Peter Nichols");
                    screen.Items.Add("Prerequisites: CS 310");
                    screen.Items.Add("Time: TTH 11a-12:45");
                    screen.Items.Add("------------------------------------------");
                }
            }


        }

        private void CS430_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {

                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 430: ");
                    screen.Items.Add("Course Name: Advanced Software Engineering");
                    screen.Items.Add("Description: Discussion of advanced topics in software engineering.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Bob Carson");
                    screen.Items.Add("Prerequisites: CS 330");
                    screen.Items.Add("Time: MW 8a-9:45");
                    screen.Items.Add("------------------------------------------");
                }
            }
        }

        private void CS445_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton r = sender as RadioButton;
            if (r != null)
            {
                if (r.Checked)
                {
                    screen.Items.Add("");
                    screen.Items.Add("------------------------------------------");
                    screen.Items.Add("Course Information about course CS 445: ");
                    screen.Items.Add("Course Name: Senior Project");
                    screen.Items.Add("Description: Students create their own personal programming project.");
                    screen.Items.Add("3 Units");
                    screen.Items.Add("Professor: Peter Nichols");
                    screen.Items.Add("Prerequisites: CS 300 and CS 330");
                    screen.Items.Add("Time: TTH 1p-2:45");
                    screen.Items.Add("------------------------------------------");
                }  
            }
        }
      

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            

        }
        private void ckCS100_CheckedChanged(object sender, EventArgs e)
            {
           
            if (futurecourses.Capacity < 6)
                {if( (!times.Contains("MW3p-445") && !times.Contains("MW4p-545") && !times.Contains("MW2p-345")) && ckCS100.Checked==true)
                    {
                        futurecourses.Add("CS100");
                        screen.Items.Add("CS100: Intro to Programming     MW 3pm-4:45     Lincoln Brown");
                        times.Add("MW3p-445");
                        rdFinished.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("Time conflict with an already registered course");
                    }
                } 
            else
            {
                ckCS100.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             
            }

            }

            private void ckCS110_CheckedChanged(object sender, EventArgs e)
            {
            
            if (futurecourses.Capacity < 6)
            {
                if ((!times.Contains("TTH1p-245") && !times.Contains("TTH2p-345") && !times.Contains("MW3p-445")) && ckCS110.Checked == true)
                {

                    futurecourses.Add("CS110");
                    screen.Items.Add("CS110: Hardware Fundamentals      TTH 1p-2:45     Lincoln Brown");
                    times.Add("TTH1p-245");
                    rdFinished.Visible = true;
                }
                else
                {
                    MessageBox.Show("Time conflict with an already registered course");
                }
            }
            else
            {
                ckCS110.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             

            }
        }

        private void ckCS145_CheckedChanged_1(object sender, EventArgs e)
        {
            if (futurecourses.Capacity < 6)
            {
                if ((!times.Contains("MW2p-345") && !times.Contains("MW1p-245") && !times.Contains("MW3p-445")) && ckCS145.Checked == true)
                {
                    futurecourses.Add("CS145");
                    screen.Items.Add("CS145: Intro to Networking        MW 2p-3:45      Nina Belle");
                    times.Add("MW2p-345");
                    rdFinished.Visible = true;
                }
                else
                {
                    MessageBox.Show("Time conflict with an already registered course");
                }
            }
            else
            {
                ckCS145.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");


            }

        }

        private void ckCS201_CheckedChanged_1(object sender, EventArgs e)
        {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS100") && (!times.Contains("TTH8a-945") && !times.Contains("TTH9a-1045") && !times.Contains("TTH10-1145")) && ckCS201.Checked == true)
                {
                    futurecourses.Add("CS201");
                    screen.Items.Add("CS201: Web Development        TTH 8a - 9:45     Timothy Vang");
                    times.Add("TTH8a-945");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS201.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS201.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");


            }

        }

        private void ckCS210_CheckedChanged(object sender, EventArgs e)
        {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS100") && (!times.Contains("MW9a-1045") && !times.Contains("MW10a-1145") && !times.Contains("MW11a-1245")) && ckCS210.Checked == true)
                {
                    futurecourses.Add("CS210");
                    screen.Items.Add("CS210: Discrete Math      MW 9a-10:45     Sonia Hernandez");
                    times.Add("MW9a-1045");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS210.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS210.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");


            }

        }

        private void ckCS220_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS100") && (!times.Contains("F2p-5") && !times.Contains("F1p-4") && !times.Contains("F3p-6")) && ckCS220.Checked == true)
                {
                    futurecourses.Add("CS220");
                    screen.Items.Add("CS220: C Programming      F 2p-5      Nina Belle");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS220.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS220.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             

            }

        }

            private void ckCS235_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS100") && (!times.Contains("TTH9a-1045") && !times.Contains("TTH10a-1145") && !times.Contains("TTH11a-1245")) && ckCS235.Checked == true)
                {
                    futurecourses.Add("CS235");
                    screen.Items.Add("CS235: Java Programming       TTH 9a-10:45        Peter Nichols");
                    times.Add("TTH9a-1045");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS235.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS235.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             

            }

        }

            private void ckCS300_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS235")&&courses.Contains("CS210") &&( !times.Contains("MW2p-345") && !times.Contains("MW1p-245") && !times.Contains("MW3p-445")) && ckCS300.Checked == true)
                {
                    futurecourses.Add("CS300");
                    screen.Items.Add("CS300: Data Structures        MW 2p-3:45      Peter Nichols");
                    times.Add("MW2p-345");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS300.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS300.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             

            }

        }

            private void ckCS310_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
               
                    if (courses.Contains("CS145")&& (!times.Contains("MW6p-745") && !times.Contains("MW5p-645") &&!times.Contains("MW7p-845")) && ckCS310.Checked == true)
                    {
                        futurecourses.Add("CS310");
                        screen.Items.Add("CS310: Computer Security      MW 6p-7:45      Timothy Vang");
                        times.Add("MW6p-745");
                        rdFinished.Visible = true;
                     }
                    else
                    {

                           
                            ckCS310.Checked=false;
                            MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
                
            }
            else
            {
                ckCS310.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
                


            }

        }

            private void ckCS330_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS300") && (!times.Contains("MW2p-345") && !times.Contains("MW1p-245") && !times.Contains("MW3p-445")) && ckCS330.Checked == true)
                {
                    futurecourses.Add("CS330");
                    screen.Items.Add("CS330: Software Engineering       MW 2p-3:45      Scott Lu");
                    times.Add("MW2p-345");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS330.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS330.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             
            }

        }

            private void ckCS335_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS300") && (!times.Contains("TTH4p-545") && !times.Contains("TTH3p-445") && !times.Contains("TTH5p-645")) && ckCS335.Checked == true)
                {
                    futurecourses.Add("CS335");
                    screen.Items.Add("CS335: Artificial Intelligence        TTH 4p-5:45     Bob Carson");
                    times.Add("TTH4p-545");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS335.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS335.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             

            }

        }

            private void ckCS345_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS335") && (!times.Contains("TTH7p-845") && !times.Contains("TTH6p-745") && !times.Contains("TTH8p-945")) && ckCS345.Checked == true)
                {
                    futurecourses.Add("CS345");
                    screen.Items.Add("CS345: Robotics        TTH 7p-8:45     Nina Belle");
                    times.Add("TTH7p-845");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS345.Checked = false;

                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS345.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             
            }

        }

            private void ckCS400_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS300")&&(!times.Contains("TTH5p-645") && !times.Contains("TTH4p-545") && !times.Contains("TTH6p-745")) && ckCS400.Checked == true)
                {
                    futurecourses.Add("CS400");
                    screen.Items.Add("CS400: Advanced Networking        TTH 5p-6:45     Scott Lu");
                    times.Add("TTH5p-645");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS400.Checked = false;

                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }

            }
            else
            {
                ckCS400.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
            
            }

        }

            private void ckCS420_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS310")&&(!times.Contains("TTH11a-1245") && !times.Contains("TTH10a-1145") ) && ckCS420.Checked == true)
                {
                    futurecourses.Add("CS 420");
                    screen.Items.Add("CS420: Advanced Computer Security        TTH 11a-12:45       Peter Nichols");
                    times.Add("TTH11a-1245");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS420.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS420.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
             
            }

        }

            private void ckCS430_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS330") && (!times.Contains("MW8a-945") && !times.Contains("TTH9a-1045") && !times.Contains("MW11a-1145")) && ckCS430.Checked==true)
                {
                    futurecourses.Add("CS430");
                    screen.Items.Add("CS430: Advanced Software Engineering     MW 8a-9:45      Bob Carson");
                    times.Add("MW8a-945");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS430.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS430.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
            
            }

        }

            private void ckCS445_CheckedChanged(object sender, EventArgs e)
            {
            if (futurecourses.Capacity < 6)
            {
                if (courses.Contains("CS300")&&courses.Contains("CS330") && (!times.Contains("TTH1p-245") && !times.Contains("TTH2p-345") && !times.Contains("TTH3p-445")) && ckCS445.Checked == true)
                {
                    futurecourses.Add("CS445");
                    screen.Items.Add("CS445: Senior Project     TTH 1p-2:45     Peter Nichols");
                    times.Add("TTH1p-245");
                    rdFinished.Visible = true;
                }
                else
                {
                    ckCS445.Checked = false;
                    MessageBox.Show("You do not meet the prerequisite and/or there is a time conflict with an already registered course");

                }
            }
            else
            {
                ckCS445.Checked = false;
                MessageBox.Show("You have reached the max units for registration.");
                
             
            }

        }
        private void query4()
        {
            //connection to the MySQL database 

            String s = screen.Items[1].ToString();
            int start = s.IndexOf('2');
            s = s.Substring(start).Trim();


            MySqlConnection connection4 = new MySqlConnection("server=127.0.0.1;user id=root; password=123; persistsecurityinfo=True;database=school; ");
            try
            {
                //The query to be used
                connection4.Open();

                for (int i = 0; i < futurecourses.Capacity; i++) {
                    MySqlCommand command4 = new MySqlCommand("INSERT INTO test (s_id, courses), VALUES('" + s + ","+futurecourses[i]+"')", connection4);
                    command4.ExecuteNonQuery();
                }
               
                

            }
            catch (MySqlException ex)
            {
                //MessageBox.Show("Error adding to database"+futurecourses.ToString());
            }
            finally
            {

                connection4.Close();
                connection4.Dispose();

            }

        }


        private void rdFinished_CheckedChanged(object sender, EventArgs e)
        {
            
            grpRegister.Visible = false;
            rdFinished.Visible = false;
            query4();
            screen.Items.Add("CHARI: Your class registration is complete");
        }
        private void query5(String id)
        {
            //connection to the MySQL database 
            String connectionString = "server=127.0.0.1;user id=root; password=123; persistsecurityinfo=True;database=school; ";
            MySqlConnection connection = new MySqlConnection(connectionString);

            try
            {
                //The query to be used
                connection.Open();
                MySqlCommand command2 = new MySqlCommand("SELECT * FROM student_current_courses WHERE s_id= " + id, connection);

                MySqlDataReader dataReader = command2.ExecuteReader();

                //returns student data 
                while (dataReader.Read())
                {


                    //return list of courses
                    for (int i = 4; i < 9; i++)
                    {
                        //"-" is a place holder for null values in the table. Do not want to return null values
                        if (dataReader.GetString(i) != "-")
                        {

                            courses.Add(dataReader.GetString(i));

                        }

                    }


                }

            }
            catch (MySqlException ex)
            {

            }
            finally
            {

                connection.Close();
                connection.Dispose();

            }

        }



        private void dropToolStripMenuItem_Click(object sender, EventArgs e)
        {
            screen.Items.Add("");
            screen.Items.Add("CHARI: You have selected 'Drop' from the menu. Please select the courses you would like to drop.");
            courseBox.Visible = false;
            grpRegister.Visible = false;
            rdFinished.Visible = false;
            grpDrop.Visible = true;
        }

        private void classRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            screen.Items.Add("");
            screen.Items.Add("CHARI: You have selected 'Class Registration' from the menu. Please select the courses you would like.");
            courseBox.Visible = false;
            grpRegister.Visible = true;
            grpDrop.Visible = false;
        }

        private void courseInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            screen.Items.Add("");
            screen.Items.Add("CHARI: You have selected 'Course Information' from the menu. ");
            screen.Items.Add("Please select the courses you would like to get more information about.");
            grpRegister.Visible = false;
            courseBox.Visible = true;
            grpDrop.Visible = false;
            rdFinished.Visible = false;

        }

        private void advisingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            screen.Items.Add("");
            screen.Items.Add("CHARI: You have selected 'Advising' from the menu.");
            grpRegister.Visible = false;
            courseBox.Visible = false;
            rdFinished.Visible = false;
            grpDrop.Visible = false;
            String s = screen.Items[1].ToString();
            int start = s.IndexOf('2');
            s = s.Substring(start).Trim();
            query2(s);
        }

        private void chkCS100_2_CheckedChanged(object sender, EventArgs e)
        {
            if(chkCS100_2.Checked=true && futurecourses.Contains("CS100"))
            {
                screen.Items.Add("CHARI: CS 100 has been dropped");
                futurecourses.Remove("CS100");
            }
            else
            {
                
                MessageBox.Show("You haven't registered for CS 100");
            }

        }

        private void chkCS110_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS110_2.Checked = true && futurecourses.Contains("CS110"))
            {
                screen.Items.Add("CHARI: CS 110 has been dropped");
                futurecourses.Remove("CS110");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 110");
            }

        }

        private void chkCS145_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS145_2.Checked = true && futurecourses.Contains("CS145"))
            {
                screen.Items.Add("CHARI: CS 145 has been dropped");
                futurecourses.Remove("CS145");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 145");
            }


        }

        private void chkCS201_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS201_2.Checked = true && futurecourses.Contains("CS201"))
            {
                screen.Items.Add("CHARI: CS 201 has been dropped");
                futurecourses.Remove("CS201");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 201");
            }

        }

        private void chkCS210_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS210_2.Checked = true && futurecourses.Contains("CS210"))
            {
                screen.Items.Add("CHARI: CS 210 has been dropped");
                futurecourses.Remove("CS210");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 210");
            }

        }

        private void chkCS220_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS100_2.Checked = true && futurecourses.Contains("CS220"))
            {
                screen.Items.Add("CHARI: CS 220 has been dropped");
                futurecourses.Remove("CS220");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 220");
            }

        }

        private void chkCS235_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS235_2.Checked = true && futurecourses.Contains("CS235"))
            {
                screen.Items.Add("CHARI: CS 235 has been dropped");
                futurecourses.Remove("CS235");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 235");
            }


        }

        private void chkCS300_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS300_2.Checked = true && futurecourses.Contains("CS300"))
            {
                screen.Items.Add("CHARI: CS 300 has been dropped");
                futurecourses.Remove("CS300");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 300");
            }


        }

        private void chkCS310_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS310_2.Checked = true && futurecourses.Contains("CS310"))
            {
                screen.Items.Add("CHARI: CS 310 has been dropped");
                futurecourses.Remove("CS310");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 310");
            }


        }

        private void chkCS330_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS330_2.Checked = true && futurecourses.Contains("CS330"))
            {
                screen.Items.Add("CHARI: CS 330 has been dropped");
                futurecourses.Remove("CS330");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 330");
            }


        }

        private void chkCS335_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS335_2.Checked = true && futurecourses.Contains("CS335"))
            {
                screen.Items.Add("CHARI: CS 335 has been dropped");
                futurecourses.Remove("CS335");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 335");
            }


        }

        private void chkCS400_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS400_2.Checked = true && futurecourses.Contains("CS400"))
            {
                screen.Items.Add("CHARI: CS 400 has been dropped");
                futurecourses.Remove("CS400");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 400");
            }


        }

        private void chkCS420_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS420_2.Checked = true && futurecourses.Contains("CS420"))
            {
                screen.Items.Add("CHARI: CS 420 has been dropped");
                futurecourses.Remove("CS420");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 420");
            }


        }

        private void chkCS430_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS430_2.Checked = true && futurecourses.Contains("CS430"))
            {
                screen.Items.Add("CHARI: CS 430 has been dropped");
                futurecourses.Remove("CS430");
            }
            else
            {
                MessageBox.Show("You haven't registered for CS 430");
            }

        }

        private void chkCS445_2_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCS445_2.Checked = true && futurecourses.Contains("CS445"))
            {
                screen.Items.Add("CHARI: CS 445 has been dropped");
                MessageBox.Show("You haven't registered for CS 445");
            }
            else
            {
                screen.Items.Add("CHARI: You haven't registered for CS 445");
            }

        }
    }
    }
