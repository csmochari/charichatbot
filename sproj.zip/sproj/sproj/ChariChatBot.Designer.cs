﻿
namespace sproj
{
    partial class ChariChatBot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChariChatBot));
            this.screen = new System.Windows.Forms.ListBox();
            this.txtBox = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnEnd = new System.Windows.Forms.Button();
            this.courseBox = new System.Windows.Forms.GroupBox();
            this.CS430 = new System.Windows.Forms.RadioButton();
            this.CS445 = new System.Windows.Forms.RadioButton();
            this.CS210 = new System.Windows.Forms.RadioButton();
            this.CS201 = new System.Windows.Forms.RadioButton();
            this.CS220 = new System.Windows.Forms.RadioButton();
            this.CS330 = new System.Windows.Forms.RadioButton();
            this.CS300 = new System.Windows.Forms.RadioButton();
            this.CS310 = new System.Windows.Forms.RadioButton();
            this.CS235 = new System.Windows.Forms.RadioButton();
            this.CS335 = new System.Windows.Forms.RadioButton();
            this.CS400 = new System.Windows.Forms.RadioButton();
            this.CS345 = new System.Windows.Forms.RadioButton();
            this.CS420 = new System.Windows.Forms.RadioButton();
            this.CS110 = new System.Windows.Forms.RadioButton();
            this.CS145 = new System.Windows.Forms.RadioButton();
            this.CS100 = new System.Windows.Forms.RadioButton();
            this.grpRegister = new System.Windows.Forms.GroupBox();
            this.ckCS145 = new System.Windows.Forms.CheckBox();
            this.ckCS201 = new System.Windows.Forms.CheckBox();
            this.ckCS445 = new System.Windows.Forms.CheckBox();
            this.ckCS345 = new System.Windows.Forms.CheckBox();
            this.ckCS330 = new System.Windows.Forms.CheckBox();
            this.ckCS300 = new System.Windows.Forms.CheckBox();
            this.ckCS220 = new System.Windows.Forms.CheckBox();
            this.ckCS210 = new System.Windows.Forms.CheckBox();
            this.ckCS430 = new System.Windows.Forms.CheckBox();
            this.ckCS420 = new System.Windows.Forms.CheckBox();
            this.ckCS400 = new System.Windows.Forms.CheckBox();
            this.ckCS335 = new System.Windows.Forms.CheckBox();
            this.ckCS310 = new System.Windows.Forms.CheckBox();
            this.ckCS235 = new System.Windows.Forms.CheckBox();
            this.ckCS110 = new System.Windows.Forms.CheckBox();
            this.ckCS100 = new System.Windows.Forms.CheckBox();
            this.rdFinished = new System.Windows.Forms.RadioButton();
            this.grpDrop = new System.Windows.Forms.GroupBox();
            this.chkCS445_2 = new System.Windows.Forms.CheckBox();
            this.chkCS430_2 = new System.Windows.Forms.CheckBox();
            this.chkCS420_2 = new System.Windows.Forms.CheckBox();
            this.chkCS400_2 = new System.Windows.Forms.CheckBox();
            this.chkCS335_2 = new System.Windows.Forms.CheckBox();
            this.chkCS330_2 = new System.Windows.Forms.CheckBox();
            this.chkCS310_2 = new System.Windows.Forms.CheckBox();
            this.chkCS300_2 = new System.Windows.Forms.CheckBox();
            this.chkCS235_2 = new System.Windows.Forms.CheckBox();
            this.chkCS220_2 = new System.Windows.Forms.CheckBox();
            this.chkCS210_2 = new System.Windows.Forms.CheckBox();
            this.chkCS201_2 = new System.Windows.Forms.CheckBox();
            this.chkCS145_2 = new System.Windows.Forms.CheckBox();
            this.chkCS110_2 = new System.Windows.Forms.CheckBox();
            this.chkCS100_2 = new System.Windows.Forms.CheckBox();
            this.advisingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.courseInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dropToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.advMenu = new System.Windows.Forms.MenuStrip();
            this.courseBox.SuspendLayout();
            this.grpRegister.SuspendLayout();
            this.grpDrop.SuspendLayout();
            this.advMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // screen
            // 
            this.screen.BackColor = System.Drawing.Color.GhostWhite;
            this.screen.Font = new System.Drawing.Font("Cambria", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.screen.FormattingEnabled = true;
            this.screen.HorizontalScrollbar = true;
            this.screen.ItemHeight = 19;
            this.screen.Location = new System.Drawing.Point(12, 40);
            this.screen.Name = "screen";
            this.screen.Size = new System.Drawing.Size(1115, 593);
            this.screen.TabIndex = 0;
            this.screen.TabStop = false;
            this.screen.UseTabStops = false;
            // 
            // txtBox
            // 
            this.txtBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBox.ForeColor = System.Drawing.Color.Black;
            this.txtBox.Location = new System.Drawing.Point(12, 652);
            this.txtBox.Name = "txtBox";
            this.txtBox.Size = new System.Drawing.Size(497, 26);
            this.txtBox.TabIndex = 1;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.Lavender;
            this.btnSubmit.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSubmit.FlatAppearance.BorderSize = 5;
            this.btnSubmit.Location = new System.Drawing.Point(579, 645);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 39);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnEnd
            // 
            this.btnEnd.BackColor = System.Drawing.Color.Lavender;
            this.btnEnd.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnEnd.FlatAppearance.BorderSize = 5;
            this.btnEnd.Location = new System.Drawing.Point(686, 645);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(75, 39);
            this.btnEnd.TabIndex = 3;
            this.btnEnd.Text = "End";
            this.btnEnd.UseVisualStyleBackColor = false;
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // courseBox
            // 
            this.courseBox.BackColor = System.Drawing.Color.Transparent;
            this.courseBox.Controls.Add(this.CS430);
            this.courseBox.Controls.Add(this.CS445);
            this.courseBox.Controls.Add(this.CS210);
            this.courseBox.Controls.Add(this.CS201);
            this.courseBox.Controls.Add(this.CS220);
            this.courseBox.Controls.Add(this.CS330);
            this.courseBox.Controls.Add(this.CS300);
            this.courseBox.Controls.Add(this.CS310);
            this.courseBox.Controls.Add(this.CS235);
            this.courseBox.Controls.Add(this.CS335);
            this.courseBox.Controls.Add(this.CS400);
            this.courseBox.Controls.Add(this.CS345);
            this.courseBox.Controls.Add(this.CS420);
            this.courseBox.Controls.Add(this.CS110);
            this.courseBox.Controls.Add(this.CS145);
            this.courseBox.Controls.Add(this.CS100);
            this.courseBox.Location = new System.Drawing.Point(879, 66);
            this.courseBox.Name = "courseBox";
            this.courseBox.Size = new System.Drawing.Size(200, 496);
            this.courseBox.TabIndex = 4;
            this.courseBox.TabStop = false;
            this.courseBox.Text = "Courses";
            this.courseBox.Visible = false;
            // 
            // CS430
            // 
            this.CS430.AutoSize = true;
            this.CS430.Location = new System.Drawing.Point(6, 442);
            this.CS430.Name = "CS430";
            this.CS430.Size = new System.Drawing.Size(83, 24);
            this.CS430.TabIndex = 15;
            this.CS430.Text = "CS430";
            this.CS430.UseVisualStyleBackColor = true;
            this.CS430.CheckedChanged += new System.EventHandler(this.CS430_CheckedChanged);
            // 
            // CS445
            // 
            this.CS445.AutoSize = true;
            this.CS445.Location = new System.Drawing.Point(6, 472);
            this.CS445.Name = "CS445";
            this.CS445.Size = new System.Drawing.Size(83, 24);
            this.CS445.TabIndex = 14;
            this.CS445.Text = "CS445";
            this.CS445.UseVisualStyleBackColor = true;
            this.CS445.CheckedChanged += new System.EventHandler(this.CS445_CheckedChanged);
            // 
            // CS210
            // 
            this.CS210.AutoSize = true;
            this.CS210.Location = new System.Drawing.Point(6, 142);
            this.CS210.Name = "CS210";
            this.CS210.Size = new System.Drawing.Size(83, 24);
            this.CS210.TabIndex = 13;
            this.CS210.Text = "CS210";
            this.CS210.UseVisualStyleBackColor = true;
            this.CS210.CheckedChanged += new System.EventHandler(this.CS210_CheckedChanged);
            // 
            // CS201
            // 
            this.CS201.AutoSize = true;
            this.CS201.Location = new System.Drawing.Point(6, 112);
            this.CS201.Name = "CS201";
            this.CS201.Size = new System.Drawing.Size(83, 24);
            this.CS201.TabIndex = 12;
            this.CS201.Text = "CS201";
            this.CS201.UseVisualStyleBackColor = true;
            this.CS201.CheckedChanged += new System.EventHandler(this.CS201_CheckedChanged);
            // 
            // CS220
            // 
            this.CS220.AutoSize = true;
            this.CS220.Location = new System.Drawing.Point(6, 172);
            this.CS220.Name = "CS220";
            this.CS220.Size = new System.Drawing.Size(83, 24);
            this.CS220.TabIndex = 11;
            this.CS220.Text = "CS220";
            this.CS220.UseVisualStyleBackColor = true;
            this.CS220.CheckedChanged += new System.EventHandler(this.CS220_CheckedChanged);
            // 
            // CS330
            // 
            this.CS330.AutoSize = true;
            this.CS330.Location = new System.Drawing.Point(6, 292);
            this.CS330.Name = "CS330";
            this.CS330.Size = new System.Drawing.Size(83, 24);
            this.CS330.TabIndex = 10;
            this.CS330.Text = "CS330";
            this.CS330.UseVisualStyleBackColor = true;
            this.CS330.CheckedChanged += new System.EventHandler(this.CS330_CheckedChanged);
            // 
            // CS300
            // 
            this.CS300.AutoSize = true;
            this.CS300.Location = new System.Drawing.Point(6, 232);
            this.CS300.Name = "CS300";
            this.CS300.Size = new System.Drawing.Size(83, 24);
            this.CS300.TabIndex = 9;
            this.CS300.Text = "CS300";
            this.CS300.UseVisualStyleBackColor = true;
            this.CS300.CheckedChanged += new System.EventHandler(this.CS300_CheckedChanged);
            // 
            // CS310
            // 
            this.CS310.AutoSize = true;
            this.CS310.Location = new System.Drawing.Point(6, 262);
            this.CS310.Name = "CS310";
            this.CS310.Size = new System.Drawing.Size(83, 24);
            this.CS310.TabIndex = 8;
            this.CS310.Text = "CS310";
            this.CS310.UseVisualStyleBackColor = true;
            this.CS310.CheckedChanged += new System.EventHandler(this.CS310_CheckedChanged);
            // 
            // CS235
            // 
            this.CS235.AutoSize = true;
            this.CS235.Location = new System.Drawing.Point(6, 202);
            this.CS235.Name = "CS235";
            this.CS235.Size = new System.Drawing.Size(83, 24);
            this.CS235.TabIndex = 7;
            this.CS235.Text = "CS235";
            this.CS235.UseVisualStyleBackColor = true;
            this.CS235.CheckedChanged += new System.EventHandler(this.CS235_CheckedChanged);
            // 
            // CS335
            // 
            this.CS335.AutoSize = true;
            this.CS335.Location = new System.Drawing.Point(6, 322);
            this.CS335.Name = "CS335";
            this.CS335.Size = new System.Drawing.Size(83, 24);
            this.CS335.TabIndex = 6;
            this.CS335.Text = "CS335";
            this.CS335.UseVisualStyleBackColor = true;
            this.CS335.CheckedChanged += new System.EventHandler(this.CS335_CheckedChanged);
            // 
            // CS400
            // 
            this.CS400.AutoSize = true;
            this.CS400.Location = new System.Drawing.Point(6, 382);
            this.CS400.Name = "CS400";
            this.CS400.Size = new System.Drawing.Size(83, 24);
            this.CS400.TabIndex = 5;
            this.CS400.Text = "CS400";
            this.CS400.UseVisualStyleBackColor = true;
            this.CS400.CheckedChanged += new System.EventHandler(this.CS400_CheckedChanged);
            // 
            // CS345
            // 
            this.CS345.AutoSize = true;
            this.CS345.Location = new System.Drawing.Point(6, 352);
            this.CS345.Name = "CS345";
            this.CS345.Size = new System.Drawing.Size(83, 24);
            this.CS345.TabIndex = 4;
            this.CS345.Text = "CS345";
            this.CS345.UseVisualStyleBackColor = true;
            this.CS345.CheckedChanged += new System.EventHandler(this.CS345_CheckedChanged);
            // 
            // CS420
            // 
            this.CS420.AutoSize = true;
            this.CS420.Location = new System.Drawing.Point(6, 412);
            this.CS420.Name = "CS420";
            this.CS420.Size = new System.Drawing.Size(83, 24);
            this.CS420.TabIndex = 3;
            this.CS420.Text = "CS420";
            this.CS420.UseVisualStyleBackColor = true;
            this.CS420.CheckedChanged += new System.EventHandler(this.CS420_CheckedChanged);
            // 
            // CS110
            // 
            this.CS110.AutoSize = true;
            this.CS110.Location = new System.Drawing.Point(6, 52);
            this.CS110.Name = "CS110";
            this.CS110.Size = new System.Drawing.Size(83, 24);
            this.CS110.TabIndex = 2;
            this.CS110.Text = "CS110";
            this.CS110.UseVisualStyleBackColor = true;
            this.CS110.CheckedChanged += new System.EventHandler(this.CS110_CheckedChanged);
            // 
            // CS145
            // 
            this.CS145.AutoSize = true;
            this.CS145.Location = new System.Drawing.Point(6, 82);
            this.CS145.Name = "CS145";
            this.CS145.Size = new System.Drawing.Size(83, 24);
            this.CS145.TabIndex = 1;
            this.CS145.Text = "CS145";
            this.CS145.UseVisualStyleBackColor = true;
            this.CS145.CheckedChanged += new System.EventHandler(this.CS145_CheckedChanged);
            // 
            // CS100
            // 
            this.CS100.AutoSize = true;
            this.CS100.Checked = true;
            this.CS100.Location = new System.Drawing.Point(6, 22);
            this.CS100.Name = "CS100";
            this.CS100.Size = new System.Drawing.Size(83, 24);
            this.CS100.TabIndex = 0;
            this.CS100.TabStop = true;
            this.CS100.Text = "CS100";
            this.CS100.UseVisualStyleBackColor = true;
            this.CS100.CheckedChanged += new System.EventHandler(this.CS100_CheckedChanged);
            // 
            // grpRegister
            // 
            this.grpRegister.BackColor = System.Drawing.Color.Transparent;
            this.grpRegister.Controls.Add(this.ckCS145);
            this.grpRegister.Controls.Add(this.ckCS201);
            this.grpRegister.Controls.Add(this.ckCS445);
            this.grpRegister.Controls.Add(this.ckCS345);
            this.grpRegister.Controls.Add(this.ckCS330);
            this.grpRegister.Controls.Add(this.ckCS300);
            this.grpRegister.Controls.Add(this.ckCS220);
            this.grpRegister.Controls.Add(this.ckCS210);
            this.grpRegister.Controls.Add(this.ckCS430);
            this.grpRegister.Controls.Add(this.ckCS420);
            this.grpRegister.Controls.Add(this.ckCS400);
            this.grpRegister.Controls.Add(this.ckCS335);
            this.grpRegister.Controls.Add(this.ckCS310);
            this.grpRegister.Controls.Add(this.ckCS235);
            this.grpRegister.Controls.Add(this.ckCS110);
            this.grpRegister.Controls.Add(this.ckCS100);
            this.grpRegister.Location = new System.Drawing.Point(879, 66);
            this.grpRegister.Name = "grpRegister";
            this.grpRegister.Size = new System.Drawing.Size(200, 504);
            this.grpRegister.TabIndex = 5;
            this.grpRegister.TabStop = false;
            this.grpRegister.Text = "Courses";
            this.grpRegister.Visible = false;
            // 
            // ckCS145
            // 
            this.ckCS145.AutoSize = true;
            this.ckCS145.Location = new System.Drawing.Point(6, 82);
            this.ckCS145.Name = "ckCS145";
            this.ckCS145.Size = new System.Drawing.Size(84, 24);
            this.ckCS145.TabIndex = 17;
            this.ckCS145.Text = "CS145";
            this.ckCS145.UseVisualStyleBackColor = true;
            this.ckCS145.CheckedChanged += new System.EventHandler(this.ckCS145_CheckedChanged_1);
            // 
            // ckCS201
            // 
            this.ckCS201.AutoSize = true;
            this.ckCS201.Location = new System.Drawing.Point(6, 112);
            this.ckCS201.Name = "ckCS201";
            this.ckCS201.Size = new System.Drawing.Size(84, 24);
            this.ckCS201.TabIndex = 16;
            this.ckCS201.Text = "CS201";
            this.ckCS201.UseVisualStyleBackColor = true;
            this.ckCS201.CheckedChanged += new System.EventHandler(this.ckCS201_CheckedChanged_1);
            // 
            // ckCS445
            // 
            this.ckCS445.AutoSize = true;
            this.ckCS445.Location = new System.Drawing.Point(6, 472);
            this.ckCS445.Name = "ckCS445";
            this.ckCS445.Size = new System.Drawing.Size(84, 24);
            this.ckCS445.TabIndex = 15;
            this.ckCS445.Text = "CS445";
            this.ckCS445.UseVisualStyleBackColor = true;
            this.ckCS445.CheckedChanged += new System.EventHandler(this.ckCS445_CheckedChanged);
            // 
            // ckCS345
            // 
            this.ckCS345.AutoSize = true;
            this.ckCS345.Location = new System.Drawing.Point(6, 352);
            this.ckCS345.Name = "ckCS345";
            this.ckCS345.Size = new System.Drawing.Size(84, 24);
            this.ckCS345.TabIndex = 14;
            this.ckCS345.Text = "CS345";
            this.ckCS345.UseVisualStyleBackColor = true;
            this.ckCS345.CheckedChanged += new System.EventHandler(this.ckCS345_CheckedChanged);
            // 
            // ckCS330
            // 
            this.ckCS330.AutoSize = true;
            this.ckCS330.Location = new System.Drawing.Point(6, 292);
            this.ckCS330.Name = "ckCS330";
            this.ckCS330.Size = new System.Drawing.Size(84, 24);
            this.ckCS330.TabIndex = 13;
            this.ckCS330.Text = "CS330";
            this.ckCS330.UseVisualStyleBackColor = true;
            this.ckCS330.CheckedChanged += new System.EventHandler(this.ckCS330_CheckedChanged);
            // 
            // ckCS300
            // 
            this.ckCS300.AutoSize = true;
            this.ckCS300.Location = new System.Drawing.Point(6, 232);
            this.ckCS300.Name = "ckCS300";
            this.ckCS300.Size = new System.Drawing.Size(84, 24);
            this.ckCS300.TabIndex = 12;
            this.ckCS300.Text = "CS300";
            this.ckCS300.UseVisualStyleBackColor = true;
            this.ckCS300.CheckedChanged += new System.EventHandler(this.ckCS300_CheckedChanged);
            // 
            // ckCS220
            // 
            this.ckCS220.AutoSize = true;
            this.ckCS220.Location = new System.Drawing.Point(6, 172);
            this.ckCS220.Name = "ckCS220";
            this.ckCS220.Size = new System.Drawing.Size(84, 24);
            this.ckCS220.TabIndex = 11;
            this.ckCS220.Text = "CS220";
            this.ckCS220.UseVisualStyleBackColor = true;
            this.ckCS220.CheckedChanged += new System.EventHandler(this.ckCS220_CheckedChanged);
            // 
            // ckCS210
            // 
            this.ckCS210.AutoSize = true;
            this.ckCS210.Location = new System.Drawing.Point(6, 142);
            this.ckCS210.Name = "ckCS210";
            this.ckCS210.Size = new System.Drawing.Size(84, 24);
            this.ckCS210.TabIndex = 10;
            this.ckCS210.Text = "CS210";
            this.ckCS210.UseVisualStyleBackColor = true;
            this.ckCS210.CheckedChanged += new System.EventHandler(this.ckCS210_CheckedChanged);
            // 
            // ckCS430
            // 
            this.ckCS430.AutoSize = true;
            this.ckCS430.Location = new System.Drawing.Point(6, 442);
            this.ckCS430.Name = "ckCS430";
            this.ckCS430.Size = new System.Drawing.Size(84, 24);
            this.ckCS430.TabIndex = 9;
            this.ckCS430.Text = "CS430";
            this.ckCS430.UseVisualStyleBackColor = true;
            this.ckCS430.CheckedChanged += new System.EventHandler(this.ckCS430_CheckedChanged);
            // 
            // ckCS420
            // 
            this.ckCS420.AutoSize = true;
            this.ckCS420.Location = new System.Drawing.Point(6, 412);
            this.ckCS420.Name = "ckCS420";
            this.ckCS420.Size = new System.Drawing.Size(84, 24);
            this.ckCS420.TabIndex = 8;
            this.ckCS420.Text = "CS420";
            this.ckCS420.UseVisualStyleBackColor = true;
            this.ckCS420.CheckedChanged += new System.EventHandler(this.ckCS420_CheckedChanged);
            // 
            // ckCS400
            // 
            this.ckCS400.AutoSize = true;
            this.ckCS400.Location = new System.Drawing.Point(6, 382);
            this.ckCS400.Name = "ckCS400";
            this.ckCS400.Size = new System.Drawing.Size(84, 24);
            this.ckCS400.TabIndex = 7;
            this.ckCS400.Text = "CS400";
            this.ckCS400.UseVisualStyleBackColor = true;
            this.ckCS400.CheckedChanged += new System.EventHandler(this.ckCS400_CheckedChanged);
            // 
            // ckCS335
            // 
            this.ckCS335.AutoSize = true;
            this.ckCS335.Location = new System.Drawing.Point(6, 322);
            this.ckCS335.Name = "ckCS335";
            this.ckCS335.Size = new System.Drawing.Size(84, 24);
            this.ckCS335.TabIndex = 6;
            this.ckCS335.Text = "CS335";
            this.ckCS335.UseVisualStyleBackColor = true;
            this.ckCS335.CheckedChanged += new System.EventHandler(this.ckCS335_CheckedChanged);
            // 
            // ckCS310
            // 
            this.ckCS310.AutoSize = true;
            this.ckCS310.Location = new System.Drawing.Point(6, 262);
            this.ckCS310.Name = "ckCS310";
            this.ckCS310.Size = new System.Drawing.Size(84, 24);
            this.ckCS310.TabIndex = 5;
            this.ckCS310.Text = "CS310";
            this.ckCS310.UseVisualStyleBackColor = true;
            this.ckCS310.CheckedChanged += new System.EventHandler(this.ckCS310_CheckedChanged);
            // 
            // ckCS235
            // 
            this.ckCS235.AutoSize = true;
            this.ckCS235.Location = new System.Drawing.Point(6, 202);
            this.ckCS235.Name = "ckCS235";
            this.ckCS235.Size = new System.Drawing.Size(84, 24);
            this.ckCS235.TabIndex = 4;
            this.ckCS235.Text = "CS235";
            this.ckCS235.UseVisualStyleBackColor = true;
            this.ckCS235.CheckedChanged += new System.EventHandler(this.ckCS235_CheckedChanged);
            // 
            // ckCS110
            // 
            this.ckCS110.AutoSize = true;
            this.ckCS110.Location = new System.Drawing.Point(6, 52);
            this.ckCS110.Name = "ckCS110";
            this.ckCS110.Size = new System.Drawing.Size(84, 24);
            this.ckCS110.TabIndex = 1;
            this.ckCS110.Text = "CS110";
            this.ckCS110.UseVisualStyleBackColor = true;
            this.ckCS110.CheckedChanged += new System.EventHandler(this.ckCS110_CheckedChanged);
            // 
            // ckCS100
            // 
            this.ckCS100.AutoSize = true;
            this.ckCS100.Location = new System.Drawing.Point(6, 22);
            this.ckCS100.Name = "ckCS100";
            this.ckCS100.Size = new System.Drawing.Size(84, 24);
            this.ckCS100.TabIndex = 0;
            this.ckCS100.Text = "CS100";
            this.ckCS100.UseVisualStyleBackColor = true;
            this.ckCS100.CheckedChanged += new System.EventHandler(this.ckCS100_CheckedChanged);
            // 
            // rdFinished
            // 
            this.rdFinished.AutoSize = true;
            this.rdFinished.Location = new System.Drawing.Point(879, 576);
            this.rdFinished.Name = "rdFinished";
            this.rdFinished.Size = new System.Drawing.Size(176, 24);
            this.rdFinished.TabIndex = 18;
            this.rdFinished.Text = "I finished registering";
            this.rdFinished.UseVisualStyleBackColor = true;
            this.rdFinished.Visible = false;
            this.rdFinished.CheckedChanged += new System.EventHandler(this.rdFinished_CheckedChanged);
            // 
            // grpDrop
            // 
            this.grpDrop.Controls.Add(this.chkCS445_2);
            this.grpDrop.Controls.Add(this.chkCS430_2);
            this.grpDrop.Controls.Add(this.chkCS420_2);
            this.grpDrop.Controls.Add(this.chkCS400_2);
            this.grpDrop.Controls.Add(this.chkCS335_2);
            this.grpDrop.Controls.Add(this.chkCS330_2);
            this.grpDrop.Controls.Add(this.chkCS310_2);
            this.grpDrop.Controls.Add(this.chkCS300_2);
            this.grpDrop.Controls.Add(this.chkCS235_2);
            this.grpDrop.Controls.Add(this.chkCS220_2);
            this.grpDrop.Controls.Add(this.chkCS210_2);
            this.grpDrop.Controls.Add(this.chkCS201_2);
            this.grpDrop.Controls.Add(this.chkCS145_2);
            this.grpDrop.Controls.Add(this.chkCS110_2);
            this.grpDrop.Controls.Add(this.chkCS100_2);
            this.grpDrop.Location = new System.Drawing.Point(879, 53);
            this.grpDrop.Name = "grpDrop";
            this.grpDrop.Size = new System.Drawing.Size(200, 517);
            this.grpDrop.TabIndex = 18;
            this.grpDrop.TabStop = false;
            this.grpDrop.Text = "Drop Classes";
            this.grpDrop.Visible = false;
            // 
            // chkCS445_2
            // 
            this.chkCS445_2.AutoSize = true;
            this.chkCS445_2.Location = new System.Drawing.Point(6, 445);
            this.chkCS445_2.Name = "chkCS445_2";
            this.chkCS445_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS445_2.TabIndex = 30;
            this.chkCS445_2.Text = "CS445";
            this.chkCS445_2.UseVisualStyleBackColor = true;
            this.chkCS445_2.CheckedChanged += new System.EventHandler(this.chkCS445_2_CheckedChanged);
            // 
            // chkCS430_2
            // 
            this.chkCS430_2.AutoSize = true;
            this.chkCS430_2.Location = new System.Drawing.Point(6, 415);
            this.chkCS430_2.Name = "chkCS430_2";
            this.chkCS430_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS430_2.TabIndex = 29;
            this.chkCS430_2.Text = "CS430";
            this.chkCS430_2.UseVisualStyleBackColor = true;
            this.chkCS430_2.CheckedChanged += new System.EventHandler(this.chkCS430_2_CheckedChanged);
            // 
            // chkCS420_2
            // 
            this.chkCS420_2.AutoSize = true;
            this.chkCS420_2.Location = new System.Drawing.Point(6, 385);
            this.chkCS420_2.Name = "chkCS420_2";
            this.chkCS420_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS420_2.TabIndex = 28;
            this.chkCS420_2.Text = "CS420";
            this.chkCS420_2.UseVisualStyleBackColor = true;
            this.chkCS420_2.CheckedChanged += new System.EventHandler(this.chkCS420_2_CheckedChanged);
            // 
            // chkCS400_2
            // 
            this.chkCS400_2.AutoSize = true;
            this.chkCS400_2.Location = new System.Drawing.Point(6, 355);
            this.chkCS400_2.Name = "chkCS400_2";
            this.chkCS400_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS400_2.TabIndex = 27;
            this.chkCS400_2.Text = "CS400";
            this.chkCS400_2.UseVisualStyleBackColor = true;
            this.chkCS400_2.CheckedChanged += new System.EventHandler(this.chkCS400_2_CheckedChanged);
            // 
            // chkCS335_2
            // 
            this.chkCS335_2.AutoSize = true;
            this.chkCS335_2.Location = new System.Drawing.Point(6, 325);
            this.chkCS335_2.Name = "chkCS335_2";
            this.chkCS335_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS335_2.TabIndex = 26;
            this.chkCS335_2.Text = "CS335";
            this.chkCS335_2.UseVisualStyleBackColor = true;
            this.chkCS335_2.CheckedChanged += new System.EventHandler(this.chkCS335_2_CheckedChanged);
            // 
            // chkCS330_2
            // 
            this.chkCS330_2.AutoSize = true;
            this.chkCS330_2.Location = new System.Drawing.Point(6, 295);
            this.chkCS330_2.Name = "chkCS330_2";
            this.chkCS330_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS330_2.TabIndex = 25;
            this.chkCS330_2.Text = "CS330";
            this.chkCS330_2.UseVisualStyleBackColor = true;
            this.chkCS330_2.CheckedChanged += new System.EventHandler(this.chkCS330_2_CheckedChanged);
            // 
            // chkCS310_2
            // 
            this.chkCS310_2.AutoSize = true;
            this.chkCS310_2.Location = new System.Drawing.Point(6, 265);
            this.chkCS310_2.Name = "chkCS310_2";
            this.chkCS310_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS310_2.TabIndex = 24;
            this.chkCS310_2.Text = "CS310";
            this.chkCS310_2.UseVisualStyleBackColor = true;
            this.chkCS310_2.CheckedChanged += new System.EventHandler(this.chkCS310_2_CheckedChanged);
            // 
            // chkCS300_2
            // 
            this.chkCS300_2.AutoSize = true;
            this.chkCS300_2.Location = new System.Drawing.Point(6, 235);
            this.chkCS300_2.Name = "chkCS300_2";
            this.chkCS300_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS300_2.TabIndex = 23;
            this.chkCS300_2.Text = "CS300";
            this.chkCS300_2.UseVisualStyleBackColor = true;
            this.chkCS300_2.CheckedChanged += new System.EventHandler(this.chkCS300_2_CheckedChanged);
            // 
            // chkCS235_2
            // 
            this.chkCS235_2.AutoSize = true;
            this.chkCS235_2.Location = new System.Drawing.Point(6, 205);
            this.chkCS235_2.Name = "chkCS235_2";
            this.chkCS235_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS235_2.TabIndex = 22;
            this.chkCS235_2.Text = "CS235";
            this.chkCS235_2.UseVisualStyleBackColor = true;
            this.chkCS235_2.CheckedChanged += new System.EventHandler(this.chkCS235_2_CheckedChanged);
            // 
            // chkCS220_2
            // 
            this.chkCS220_2.AutoSize = true;
            this.chkCS220_2.Location = new System.Drawing.Point(6, 175);
            this.chkCS220_2.Name = "chkCS220_2";
            this.chkCS220_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS220_2.TabIndex = 21;
            this.chkCS220_2.Text = "CS220";
            this.chkCS220_2.UseVisualStyleBackColor = true;
            this.chkCS220_2.CheckedChanged += new System.EventHandler(this.chkCS220_2_CheckedChanged);
            // 
            // chkCS210_2
            // 
            this.chkCS210_2.AutoSize = true;
            this.chkCS210_2.Location = new System.Drawing.Point(6, 145);
            this.chkCS210_2.Name = "chkCS210_2";
            this.chkCS210_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS210_2.TabIndex = 20;
            this.chkCS210_2.Text = "CS210";
            this.chkCS210_2.UseVisualStyleBackColor = true;
            this.chkCS210_2.CheckedChanged += new System.EventHandler(this.chkCS210_2_CheckedChanged);
            // 
            // chkCS201_2
            // 
            this.chkCS201_2.AutoSize = true;
            this.chkCS201_2.Location = new System.Drawing.Point(6, 115);
            this.chkCS201_2.Name = "chkCS201_2";
            this.chkCS201_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS201_2.TabIndex = 19;
            this.chkCS201_2.Text = "CS201";
            this.chkCS201_2.UseVisualStyleBackColor = true;
            this.chkCS201_2.CheckedChanged += new System.EventHandler(this.chkCS201_2_CheckedChanged);
            // 
            // chkCS145_2
            // 
            this.chkCS145_2.AutoSize = true;
            this.chkCS145_2.Location = new System.Drawing.Point(6, 85);
            this.chkCS145_2.Name = "chkCS145_2";
            this.chkCS145_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS145_2.TabIndex = 18;
            this.chkCS145_2.Text = "CS145";
            this.chkCS145_2.UseVisualStyleBackColor = true;
            this.chkCS145_2.CheckedChanged += new System.EventHandler(this.chkCS145_2_CheckedChanged);
            // 
            // chkCS110_2
            // 
            this.chkCS110_2.AutoSize = true;
            this.chkCS110_2.Location = new System.Drawing.Point(6, 55);
            this.chkCS110_2.Name = "chkCS110_2";
            this.chkCS110_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS110_2.TabIndex = 2;
            this.chkCS110_2.Text = "CS110";
            this.chkCS110_2.UseVisualStyleBackColor = true;
            this.chkCS110_2.CheckedChanged += new System.EventHandler(this.chkCS110_2_CheckedChanged);
            // 
            // chkCS100_2
            // 
            this.chkCS100_2.AutoSize = true;
            this.chkCS100_2.Location = new System.Drawing.Point(6, 25);
            this.chkCS100_2.Name = "chkCS100_2";
            this.chkCS100_2.Size = new System.Drawing.Size(84, 24);
            this.chkCS100_2.TabIndex = 1;
            this.chkCS100_2.Text = "CS100";
            this.chkCS100_2.UseVisualStyleBackColor = true;
            this.chkCS100_2.CheckedChanged += new System.EventHandler(this.chkCS100_2_CheckedChanged);
            // 
            // advisingToolStripMenuItem
            // 
            this.advisingToolStripMenuItem.Name = "advisingToolStripMenuItem";
            this.advisingToolStripMenuItem.Size = new System.Drawing.Size(97, 30);
            this.advisingToolStripMenuItem.Text = "Advising";
            this.advisingToolStripMenuItem.Click += new System.EventHandler(this.advisingToolStripMenuItem_Click);
            // 
            // courseInformationToolStripMenuItem
            // 
            this.courseInformationToolStripMenuItem.Name = "courseInformationToolStripMenuItem";
            this.courseInformationToolStripMenuItem.Size = new System.Drawing.Size(182, 30);
            this.courseInformationToolStripMenuItem.Text = "Course Information";
            this.courseInformationToolStripMenuItem.Click += new System.EventHandler(this.courseInformationToolStripMenuItem_Click);
            // 
            // classRegistrationToolStripMenuItem
            // 
            this.classRegistrationToolStripMenuItem.Name = "classRegistrationToolStripMenuItem";
            this.classRegistrationToolStripMenuItem.Size = new System.Drawing.Size(182, 30);
            this.classRegistrationToolStripMenuItem.Text = "Course Registration";
            this.classRegistrationToolStripMenuItem.Click += new System.EventHandler(this.classRegistrationToolStripMenuItem_Click);
            // 
            // dropToolStripMenuItem
            // 
            this.dropToolStripMenuItem.Name = "dropToolStripMenuItem";
            this.dropToolStripMenuItem.Size = new System.Drawing.Size(129, 30);
            this.dropToolStripMenuItem.Text = "Drop Course";
            this.dropToolStripMenuItem.Click += new System.EventHandler(this.dropToolStripMenuItem_Click);
            // 
            // advMenu
            // 
            this.advMenu.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.advMenu.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.advMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.advisingToolStripMenuItem,
            this.courseInformationToolStripMenuItem,
            this.classRegistrationToolStripMenuItem,
            this.dropToolStripMenuItem});
            this.advMenu.Location = new System.Drawing.Point(0, 0);
            this.advMenu.Name = "advMenu";
            this.advMenu.Size = new System.Drawing.Size(1139, 36);
            this.advMenu.TabIndex = 20;
            this.advMenu.Visible = false;
            // 
            // ChariChatBot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1139, 701);
            this.Controls.Add(this.grpDrop);
            this.Controls.Add(this.rdFinished);
            this.Controls.Add(this.grpRegister);
            this.Controls.Add(this.courseBox);
            this.Controls.Add(this.btnEnd);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtBox);
            this.Controls.Add(this.screen);
            this.Controls.Add(this.advMenu);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ChariChatBot";
            this.Text = "CHARI";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.courseBox.ResumeLayout(false);
            this.courseBox.PerformLayout();
            this.grpRegister.ResumeLayout(false);
            this.grpRegister.PerformLayout();
            this.grpDrop.ResumeLayout(false);
            this.grpDrop.PerformLayout();
            this.advMenu.ResumeLayout(false);
            this.advMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox screen;
        private System.Windows.Forms.TextBox txtBox;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.GroupBox courseBox;
        private System.Windows.Forms.RadioButton CS100;
        private System.Windows.Forms.RadioButton CS430;
        private System.Windows.Forms.RadioButton CS445;
        private System.Windows.Forms.RadioButton CS210;
        private System.Windows.Forms.RadioButton CS201;
        private System.Windows.Forms.RadioButton CS220;
        private System.Windows.Forms.RadioButton CS330;
        private System.Windows.Forms.RadioButton CS300;
        private System.Windows.Forms.RadioButton CS310;
        private System.Windows.Forms.RadioButton CS235;
        private System.Windows.Forms.RadioButton CS335;
        private System.Windows.Forms.RadioButton CS400;
        private System.Windows.Forms.RadioButton CS345;
        private System.Windows.Forms.RadioButton CS420;
        private System.Windows.Forms.RadioButton CS110;
        private System.Windows.Forms.RadioButton CS145;
        private System.Windows.Forms.GroupBox grpRegister;
        private System.Windows.Forms.CheckBox ckCS445;
        private System.Windows.Forms.CheckBox ckCS345;
        private System.Windows.Forms.CheckBox ckCS330;
        private System.Windows.Forms.CheckBox ckCS300;
        private System.Windows.Forms.CheckBox ckCS220;
        private System.Windows.Forms.CheckBox ckCS210;
        private System.Windows.Forms.CheckBox ckCS430;
        private System.Windows.Forms.CheckBox ckCS420;
        private System.Windows.Forms.CheckBox ckCS400;
        private System.Windows.Forms.CheckBox ckCS335;
        private System.Windows.Forms.CheckBox ckCS310;
        private System.Windows.Forms.CheckBox ckCS235;
        private System.Windows.Forms.CheckBox ckCS110;
        private System.Windows.Forms.CheckBox ckCS100;
        private System.Windows.Forms.RadioButton rdFinished;
        private System.Windows.Forms.CheckBox ckCS145;
        private System.Windows.Forms.CheckBox ckCS201;
        private System.Windows.Forms.GroupBox grpDrop;
        private System.Windows.Forms.CheckBox chkCS445_2;
        private System.Windows.Forms.CheckBox chkCS430_2;
        private System.Windows.Forms.CheckBox chkCS420_2;
        private System.Windows.Forms.CheckBox chkCS400_2;
        private System.Windows.Forms.CheckBox chkCS335_2;
        private System.Windows.Forms.CheckBox chkCS330_2;
        private System.Windows.Forms.CheckBox chkCS310_2;
        private System.Windows.Forms.CheckBox chkCS300_2;
        private System.Windows.Forms.CheckBox chkCS235_2;
        private System.Windows.Forms.CheckBox chkCS220_2;
        private System.Windows.Forms.CheckBox chkCS210_2;
        private System.Windows.Forms.CheckBox chkCS201_2;
        private System.Windows.Forms.CheckBox chkCS145_2;
        private System.Windows.Forms.CheckBox chkCS110_2;
        private System.Windows.Forms.CheckBox chkCS100_2;
        private System.Windows.Forms.ToolStripMenuItem advisingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem courseInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dropToolStripMenuItem;
        private System.Windows.Forms.MenuStrip advMenu;
    }
}

